# Write program to calculate area, perimeter of circle

#input radius
radius = eval(input("Enter radius of circle: "))

#calculate area
area = 3.14 * radius * radius

#calculate perimeter
perimeter = 2 * 3.14 * radius

#print area and perimeter
print("Area of circle is: ", area, "and perimeter is: ", perimeter)