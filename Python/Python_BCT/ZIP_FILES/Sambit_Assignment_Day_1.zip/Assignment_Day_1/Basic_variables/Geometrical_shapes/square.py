# Write a program to calculate area, perimeter of square

#input side
side = eval(input("\tEnter side of square: "))

#calculate area
area = side * side

#calculate perimeter
perimeter = 4 * side

#print area and perimeter

print("\tArea of square is: ", area, ";\t perimeter is: ", perimeter)