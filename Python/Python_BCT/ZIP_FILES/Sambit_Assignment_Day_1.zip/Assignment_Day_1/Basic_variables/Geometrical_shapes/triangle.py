# Write a program to calculate area, perimeter of triangle

#input side
side = eval(input("\tEnter side of triangle: "))

#calculate area
area = side * side

#calculate perimeter
perimeter = 4 * side

#print area and perimeter

print("\tArea of triangle is: ", area, ";\t perimeter is: ", perimeter)