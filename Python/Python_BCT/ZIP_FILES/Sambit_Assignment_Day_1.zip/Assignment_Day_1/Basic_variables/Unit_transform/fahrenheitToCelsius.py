# Write a program to convert temperature from Fahrenheit to Celsius

#input temperature in Fahrenheit
fahrenheit = eval(input("Enter temperature in Fahrenheit: "))

#print temperature in Celsius
print("Temperature in Celsius is: ", ((fahrenheit - 32) * 5/9))