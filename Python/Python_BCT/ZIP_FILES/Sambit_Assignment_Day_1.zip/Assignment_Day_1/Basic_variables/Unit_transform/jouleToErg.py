# Write a program to convert Joule to Erg

#input energy in Joule
joule = eval(input("Enter energy in Joule: "))

#print energy in Erg
print("Energy in Erg is: ", (joule * 10000000))