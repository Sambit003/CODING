# Write a program to convert Kg to Gram and Milligram

#input weight in Kg
kg = eval(input("Enter weight in Kg: "))

#print weight in Gram and Milligram
print("Weight in Gram is: ", (kg * 1000), "and weight in Milligram is: ", (kg * 1000000))