# Write a program to convert m/s to km/h

#input speed in m/s
mPerS = eval(input("Enter speed in m/s: "))

# print speed in km/h
print("Speed in km/h is: ", (mPerS * 3.6))