# Write a program to convert Meter per second to Mile per hour

#input speed in Meter per second
mPerS = eval(input("Enter speed in Meter per second: "))

# print speed in Mile per hour
print("Speed in Mile per hour is: ", (mPerS * 2.23693629))