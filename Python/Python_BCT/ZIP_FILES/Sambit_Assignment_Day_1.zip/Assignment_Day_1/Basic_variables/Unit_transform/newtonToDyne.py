# Write a program to convert Newton to Dyne

#input force in Newton
newton = eval(input("Enter force in Newton: "))

#print force in Dyne
print("Force in Dyne is: ", (newton * 100000))
