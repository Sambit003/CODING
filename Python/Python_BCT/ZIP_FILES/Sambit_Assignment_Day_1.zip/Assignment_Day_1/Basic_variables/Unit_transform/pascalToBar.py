# Write a program to convert Pascal to bar


# Get the Pascal value from the user
pascal = float(input("Enter the Pascal value: "))

# Convert the Pascal value to bar
bar = pascal / 100000

# Print the bar value
print("The bar value is: ", bar)

