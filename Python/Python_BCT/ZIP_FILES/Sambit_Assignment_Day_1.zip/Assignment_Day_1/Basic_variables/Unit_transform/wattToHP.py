# Write a program to convert Watt to Horsepower

#input power in Watt
watt = eval(input("Enter power in Watt: "))

#print power in Horsepower
print("Power in Horsepower is: ", (watt * 0.001341022))