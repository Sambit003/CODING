# Write a program to find the largest among two numbers given by user

#input first & second number
firstNumber, secondNumber = eval(input("Enter two numbers: "))

#compare firstNumber and secondNumber
if firstNumber > secondNumber:
    print("First number is largest")
else:
    print("Second number is largest")