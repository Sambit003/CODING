# write a program to find the LCM of two numbers given by user using other formula.

# Input: 2 numbers
num1, num2 = eval(input("Enter two numbers: "))

# find the LCM of two numbers
if num1 > num2:
    greater = num1
else:
    greater = num2

while True:
    if greater % num1 == 0 and greater % num2 == 0:
        lcm = greater
        break
    greater += 1

# Output: LCM of two numbers
print("LCM of two numbers is", lcm)